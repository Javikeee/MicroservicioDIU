import axios from "axios";

export default axios.create({
  baseURL: "http://prueba-env.eba-nsmdjnmp.us-east-1.elasticbeanstalk.com",
  headers: {
    "Content-type": "application/json"
  }
});